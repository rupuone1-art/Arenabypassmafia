import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side Gemini API route (Non-streaming)
app.post('/api/gemini/generate', async (req, res) => {
  const { systemPrompt, userPrompt, temperature } = req.body;
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server' });
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `${systemPrompt ? `[SYSTEM INSTRUCTIONS]:\n${systemPrompt}\n\n` : ''}${userPrompt}`,
            },
          ],
        },
      ],
      config: {
        temperature: typeof temperature === 'number' ? temperature : 0.85,
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '';
    return res.json({ text });
  } catch (err: any) {
    console.error('Server Gemini generate error:', err?.message || err);
    return res.status(500).json({ error: err?.message || 'Server Gemini API error' });
  }
});

// Server-side Gemini API route (SSE Streaming)
app.post('/api/gemini/stream', async (req, res) => {
  const { systemPrompt, userPrompt, temperature } = req.body;
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    const ai = new GoogleGenAI({ apiKey });
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `${systemPrompt ? `[SYSTEM INSTRUCTIONS]:\n${systemPrompt}\n\n` : ''}${userPrompt}`,
            },
          ],
        },
      ],
      config: {
        temperature: typeof temperature === 'number' ? temperature : 0.85,
      },
    });

    for await (const chunk of responseStream) {
      const chunkText = chunk.text || '';
      if (chunkText) {
        res.write(`data: ${JSON.stringify({ text: chunkText })}\n\n`);
      }
    }
    res.write('data: [DONE]\n\n');
    res.end();
  } catch (err: any) {
    res.write(`data: ${JSON.stringify({ error: err?.message || 'Streaming failed' })}\n\n`);
    res.end();
  }
});

// Proxy for Yukino completions
app.post('/api/yukino/v1/chat/completions', async (req, res) => {
  try {
    const yukinoRes = await fetch('https://api.yukino.my/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer sk-yuk-a43a6e0502c6194f1de894635560c3ab',
      },
      body: JSON.stringify(req.body),
    });

    const contentType = yukinoRes.headers.get('content-type') || 'text/plain';
    res.setHeader('Content-Type', contentType);
    const body = await yukinoRes.text();
    return res.status(yukinoRes.status).send(body);
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Yukino proxy failure' });
  }
});

// Vite middleware in dev or static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
} else {
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
    appType: 'spa',
  });
  app.use(vite.middlewares);
}

app.listen(port, '0.0.0.0', () => {
  console.log(`Server listening on port ${port}`);
});
